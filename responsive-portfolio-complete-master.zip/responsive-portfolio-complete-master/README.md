# Responsive Portfolio Complete
## [Watch it on youtube](https://youtu.be/owEHlDn0JYQ)
### Responsive Portfolio Complete
Learn how to develop a clean and nice web portfolio, fully mobile first and responsive, for a designer or developer. Includes a side menu bar. At the beginning, your name, links to social networks and an image. Then the About section shows more information about you. Y Contains a list of skills offered.

It also has a part where you show your education studies with a timeline. Then a section where he offers his services and a section on Recent Jobs. And at the bottom you have a contact form, and at the bottom a footer.

Don't forget to join the channel for more videos like this.
[Bedimcode](https://www.youtube.com/c/Bedimcode)
